GROWW SMART ALGO — ANDROID-FRIENDLY STARTER BUILD 1.0

WHAT THIS IS
A mobile-friendly Streamlit dashboard that can be opened in an Android browser once hosted. It supports English/Kannada UI labels, CSV candle upload, EMA/RSI/session-VWAP calculations, basic BUY WATCH/SELL WATCH/WAIT signals, illustrative stop/target sizing, and paper-review buttons.

IMPORTANT LIMITATIONS
- No Groww connection is implemented.
- No live market feed is implemented.
- No real order placement, modification, or cancellation is implemented.
- No Telegram notifications or persistent portfolio database yet.
- F&O signals are analysis-only; options contracts need separate expiry/strike/lot-size logic.
- Signals are educational examples, not investment advice or evidence of profitability.

RUN LOCALLY
1. Install Python 3.10+ on a computer or deploy this app to a trusted Python hosting service.
2. Install packages: pip install -r requirements.txt
3. Run: streamlit run app.py
4. Open the displayed web address in a browser.

ANDROID USE
For phone access, deploy the app to a trusted cloud host with access controls, then open its HTTPS address in Chrome on Android. Use Chrome menu > Add to Home screen. The app is not a native APK.

CSV FORMAT
Required headers: datetime,open,high,low,close,volume
Use historical/paper OHLCV data. Timestamps should be in Asia/Kolkata for correct daily VWAP resets.

NEXT STEPS BEFORE ANY LIVE TRADING
1. Verify Groww API availability, account eligibility, permissions, pricing and official documentation.
2. Verify current SEBI/exchange retail-algo and broker requirements.
3. Add secure credential handling (environment variables/secrets manager; never hard-code keys).
4. Add validated market-data mapping, exchange calendar, symbol master and contract/lot-size handling.
5. Add historical backtests with brokerage, taxes, slippage and realistic fills.
6. Paper trade over a meaningful sample and review drawdowns.
7. Only then consider a separate manual-confirmation order module with preview, risk limits, kill switch and order reconciliation.

Official Groww API documentation: https://groww.in/trade-api/docs
